const html = `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#111">
<title>Meu Sistema de Vendas</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;background:#f4f5f7;color:#111}
.wrap{max-width:900px;margin:auto;padding:14px}.top{background:#111;color:#fff;border-radius:16px;padding:18px;margin-bottom:12px}.top h1{margin:0 0 5px;font-size:23px}.top p{margin:0;color:#ddd;font-size:13px}
.menu{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}.menu button{min-height:52px;padding:10px 4px;border:1px solid #ddd;background:#fff;border-radius:12px;font-weight:700;font-size:14px}.menu button.on{background:#111;color:#fff}
.card{background:#fff;border:1px solid #ddd;border-radius:15px;padding:15px;margin-bottom:12px}.btn{background:#111;color:#fff;border:0;border-radius:10px;padding:12px 15px;font-weight:700;font-size:15px}.btn.gray{background:#eee;color:#111}.btn.green{background:#16803c;color:#fff}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.prod{border:1px solid #ddd;border-radius:14px;overflow:hidden;background:#fff}.photo{height:150px;background:#eee;display:flex;align-items:center;justify-content:center;font-size:45px}.photo img{width:100%;height:100%;object-fit:cover}
.info{padding:11px}.muted{font-size:12px;color:#777}.price{font-size:18px;font-weight:800;margin:6px 0}.row{display:flex;gap:8px;align-items:center;justify-content:space-between;margin:7px 0}.field{margin:11px 0}.field label{display:block;font-size:12px;color:#666;margin-bottom:5px;font-weight:600}.field input,.field select{width:100%;padding:13px;border:1px solid #ccc;border-radius:10px;font-size:16px;background:#fff}
.hidden{display:none!important}.empty{text-align:center;color:#777;padding:25px}.item{border-bottom:1px solid #eee;padding:11px 0}.total{display:flex;justify-content:space-between;font-weight:800;font-size:19px;margin-top:12px}.badge{display:inline-block;background:#eee;border-radius:20px;padding:5px 9px;font-size:12px}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.55);display:none;align-items:center;justify-content:center;padding:15px;z-index:100}.modal.open{display:flex}.box{background:#fff;border-radius:16px;padding:17px;width:min(560px,100%);max-height:90vh;overflow:auto}
.notice{background:#f7f7f7;border-radius:10px;padding:11px;font-size:14px;margin:8px 0}.success{background:#e9f8ed;padding:12px;border-radius:10px;margin-top:10px}
@media(max-width:520px){.grid{grid-template-columns:1fr}.menu button{font-size:13px}.photo{height:180px}}
</style>
</head>
<body>
<div class="wrap">
<div class="top"><h1>Meu Sistema de Vendas</h1><p>Clientes • Rotas • Produtos • Vendas • Pedidos</p></div>
<div class="menu">
<button data-page="home">🏠 Início</button><button data-page="products">🛍️ Produtos</button><button data-page="orders">📋 Pedidos</button>
<button data-page="clients">👥 Clientes</button><button data-page="sales">💰 Vendas</button><button data-page="routes">🗺️ Rotas</button>
</div>

<section id="home" class="page">
<div class="card"><h2>Resumo</h2><div id="summary"></div></div>
<div class="card"><h2>Como usar</h2><p>1. Cadastre as rotas.</p><p>2. Cadastre os clientes e escolha a rota.</p><p>3. Cadastre os produtos.</p><p>4. Em Vendas, escolha o cliente e os produtos.</p><p>5. Cada cliente pode receber um link próprio para fazer pedidos pelo catálogo.</p></div>
</section>

<section id="products" class="page hidden"><div class="card"><div class="row"><h2>🛍️ Produtos</h2><button class="btn" id="addProduct">+ Produto</button></div><div id="productsList" class="grid"></div></div></section>
<section id="clients" class="page hidden"><div class="card"><div class="row"><h2>👥 Clientes</h2><button class="btn" id="addClient">+ Cliente</button></div><div id="clientsList"></div></div></section>
<section id="routes" class="page hidden"><div class="card"><div class="row"><h2>🗺️ Rotas</h2><button class="btn" id="addRoute">+ Rota</button></div><div id="routesList"></div></div></section>
<section id="sales" class="page hidden"><div class="card"><h2>💰 Vendas</h2><div id="salesList"></div></div></section>
<section id="orders" class="page hidden"><div class="card"><h2>📋 Pedidos recebidos</h2><div id="ordersList"></div></div></section>
</div>
<div id="modal" class="modal"><div class="box" id="box"></div></div>

<script>
let DATA={products:[],clients:[],routes:[],orders:[]}, cart=[];
const $=id=>document.getElementById(id);
const br=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Number(n)||0);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function api(path,opt={}){let r=await fetch('/api/'+path,{headers:{'content-type':'application/json',...(opt.headers||{})},...opt});let x=await r.json().catch(()=>({}));if(!r.ok)throw Error(x.error||'Erro');return x}
async function load(){DATA=await api('bootstrap');render()}
function show(p){document.querySelectorAll('.page').forEach(x=>x.classList.toggle('hidden',x.id!==p));document.querySelectorAll('.menu button').forEach(x=>x.classList.toggle('on',x.dataset.page===p));render()}
document.querySelectorAll('.menu button').forEach(b=>b.onclick=()=>show(b.dataset.page));
function openModal(s){$('box').innerHTML=s;$('modal').classList.add('open')}function closeModal(){$('modal').classList.remove('open')}
$('modal').onclick=e=>{if(e.target===$('modal'))closeModal()};

function productForm(){openModal(`<h2>Novo produto</h2>
<div class="field"><label>Nome</label><input id="pName" placeholder="Jogo de cama"></div>
<div class="field"><label>Preço de venda</label><input id="pPrice" type="number" step="0.01" inputmode="decimal" placeholder="149,90"></div>
<div class="field"><label>Código</label><input id="pCode" placeholder="001"></div>
<div class="field"><label>Foto (opcional)</label><input id="pImg" type="file" accept="image/*"></div>
<div class="row"><button class="btn gray" onclick="closeModal()">Cancelar</button><button class="btn" id="saveP">Salvar</button></div>`);
$('saveP').onclick=async()=>{let n=$('pName').value.trim(),p=Number($('pPrice').value),c=$('pCode').value.trim(),f=$('pImg').files[0];if(!n||p<=0)return alert('Informe nome e preço.');let photo='';if(f){photo=await new Promise(res=>{let r=new FileReader();r.onload=()=>res(r.result);r.readAsDataURL(f)})}try{await api('products',{method:'POST',body:JSON.stringify({name:n,price:p,code:c,photo_url:photo})});closeModal();await load()}catch(e){alert(e.message)}}
}
$('addProduct').onclick=productForm;

function clientForm(){let opts=DATA.routes.map(r=>`<option value="${r.id}">${esc(r.name)} — ${esc(r.city)}${r.date?' — '+esc(r.date):''}</option>`).join('');openModal(`<h2>Novo cliente</h2>
<div class="field"><label>Nome</label><input id="cName" placeholder="João da Silva"></div>
<div class="field"><label>Telefone</label><input id="cPhone" inputmode="tel" placeholder="(00) 00000-0000"></div>
<div class="field"><label>Rota / cidade</label><select id="cRoute"><option value="">Selecione a rota</option>${opts}</select></div>
<div class="notice">A cidade será puxada automaticamente da rota escolhida.</div>
<div class="row"><button class="btn gray" onclick="closeModal()">Cancelar</button><button class="btn" id="saveC">Salvar</button></div>`);
$('saveC').onclick=async()=>{let n=$('cName').value.trim(),ph=$('cPhone').value.trim(),r=$('cRoute').value;if(!n||!r)return alert('Informe nome e rota.');try{await api('clients',{method:'POST',body:JSON.stringify({name:n,phone:ph,route_id:r})});closeModal();await load()}catch(e){alert(e.message)}}
}
$('addClient').onclick=clientForm;

function routeForm(){openModal(`<h2>Nova rota</h2><div class="field"><label>Nome da rota</label><input id="rName" placeholder="Curvelo"></div>
<div class="field"><label>Cidade</label><input id="rCity" placeholder="Curvelo"></div><div class="field"><label>Data</label><input id="rDate" type="date"></div>
<div class="row"><button class="btn gray" onclick="closeModal()">Cancelar</button><button class="btn" id="saveR">Salvar</button></div>`);
$('saveR').onclick=async()=>{let n=$('rName').value.trim(),c=$('rCity').value.trim(),d=$('rDate').value;if(!n||!c)return alert('Informe nome e cidade.');try{await api('routes',{method:'POST',body:JSON.stringify({name:n,city:c,date:d})});closeModal();await load()}catch(e){alert(e.message)}}
}
$('addRoute').onclick=routeForm;

function addToSale(id){let x=cart.find(i=>i.id===id);if(x)x.q++;else cart.push({id,q:1});renderProducts()}
function renderProducts(){let d=$('productsList');d.innerHTML=DATA.products.length?DATA.products.map(p=>`<div class="prod"><div class="photo">${p.photo_url?`<img src="${p.photo_url}" alt="">`:'📦'}</div><div class="info"><div class="muted">Código: ${esc(p.code||'-')}</div><b>${esc(p.name)}</b><div class="price">${br(p.price)}</div><button class="btn" onclick="addToSale('${p.id}')">Adicionar à venda</button></div></div>`).join(''):`<div class="empty" style="grid-column:1/-1">Nenhum produto cadastrado.</div>`}
function saleForm(){if(!DATA.clients.length)return alert('Cadastre um cliente primeiro.');let opts=DATA.clients.map(c=>`<option value="${c.id}">${esc(c.name)} — ${esc(c.city)}</option>`).join('');let lines=cart.map(i=>{let p=DATA.products.find(x=>x.id===i.id);return `<div class="item">${esc(p.name)} — ${i.q}x — ${br(p.price*i.q)}</div>`}).join('');openModal(`<h2>Finalizar venda</h2><div class="notice">${lines}</div><div class="field"><label>Cliente</label><select id="sClient"><option value="">Selecione</option>${opts}</select></div><div class="field"><label>Pagamento</label><select id="sPay"><option>60 dias</option><option>À vista</option><option>Pix</option><option>Cartão</option></select></div><div class="row"><button class="btn gray" onclick="closeModal()">Cancelar</button><button class="btn" id="confirmS">Salvar venda</button></div>`);
$('confirmS').onclick=async()=>{let c=$('sClient').value;if(!c)return alert('Selecione o cliente.');try{await api('sales',{method:'POST',body:JSON.stringify({client_id:c,payment:$('sPay').value,items:cart.map(i=>({product_id:i.id,quantity:i.q}))})});cart=[];closeModal();await load();show('sales')}catch(e){alert(e.message)}}
}
function renderSaleCart(){let old=$('saleCart');if(old)old.remove();let d=document.createElement('div');d.id='saleCart';d.className='card';let total=0;let rows=cart.map(i=>{let p=DATA.products.find(x=>x.id===i.id);if(!p)return '';total+=p.price*i.q;return `<div class="row"><span>${esc(p.name)} (${i.q}x)</span><b>${br(p.price*i.q)}</b></div>`}).join('');d.innerHTML=`<h3>🛒 Venda em montagem</h3>${rows||'<div class="empty">Nenhum produto selecionado.</div>'}${rows?`<div class="total"><span>Total</span><span>${br(total)}</span></div><br><button class="btn green" onclick="saleForm()">Finalizar venda</button>`:''}`;$('products').appendChild(d)}
function renderClients(){let d=$('clientsList');d.innerHTML=DATA.clients.length?DATA.clients.map(c=>{let r=DATA.routes.find(x=>x.id===c.route_id);let link=location.origin+'/catalog.html?cliente='+encodeURIComponent(c.public_token);return `<div class="item"><b>${esc(c.name)}</b><br><span class="muted">${esc(c.phone||'')} • ${esc(c.city)}</span><br><span class="small">Rota: ${esc(r?.name||'-')}</span><div class="row"><button class="btn gray" onclick="navigator.clipboard?.writeText('${link}');alert('Link copiado')">Copiar link do cliente</button><a class="btn" href="https://wa.me/?text=${encodeURIComponent('Seu catálogo de pedidos: '+link)}" target="_blank">WhatsApp</a></div></div>`}).join(''):'<div class="empty">Nenhum cliente cadastrado.</div>'}
function renderRoutes(){let d=$('routesList');d.innerHTML=DATA.routes.length?DATA.routes.map(r=>`<div class="item"><b>${esc(r.name)}</b><br>${esc(r.city)} ${r.date?'• '+esc(r.date):''}<br><span class="muted">${DATA.clients.filter(c=>c.route_id===r.id).length} cliente(s)</span></div>`).join(''):'<div class="empty">Nenhuma rota cadastrada.</div>'}
function wa(o){let lines=o.items.map(i=>`${i.quantity}x ${i.product_name} — ${br(i.line_total)}`).join('\\n');let msg=`VENDA REALIZADA\\nCliente: ${o.client_name}\\nCidade: ${o.city}\\nRota: ${o.route_name}\\n${lines}\\nTOTAL: ${br(o.total)}\\nPagamento: ${o.payment}`;return 'https://wa.me/?text='+encodeURIComponent(msg)}
function renderOrders(){let d=$('ordersList');d.innerHTML=DATA.orders.length?DATA.orders.map(o=>`<div class="item"><b>${esc(o.client_name)}</b> <span class="badge">${esc(o.status)}</span><br>${esc(o.city)} • ${esc(o.route_name)}<br>${o.items.map(i=>`${i.quantity}x ${esc(i.product_name)}`).join(', ')}<br><b>${br(o.total)}</b><div class="row"><button class="btn green" onclick="att('${o.id}')">Marcar atendido</button><a class="btn" href="${wa(o)}" target="_blank">WhatsApp</a></div></div>`).join(''):'<div class="empty">Nenhum pedido recebido.</div>'}
async function att(id){try{await api('orders/'+id,{method:'PATCH',body:JSON.stringify({status:'Atendido'})});await load()}catch(e){alert(e.message)}}
function renderSales(){let d=$('salesList');d.innerHTML=DATA.orders.length?DATA.orders.map(o=>`<div class="item"><b>${esc(o.client_name)}</b> • ${esc(o.city)}<br>Rota: ${esc(o.route_name)} • ${esc(o.route_date||'-')}<br>${o.items.map(i=>`${i.quantity}x ${esc(i.product_name)}`).join(', ')}<br><b>${br(o.total)}</b> • ${esc(o.payment)} <span class="badge">${esc(o.status)}</span></div>`).join(''):'<div class="empty">Nenhuma venda registrada.</div>'}
function renderHome(){$('summary').innerHTML=`<div class="grid"><div class="card"><b>${DATA.products.length}</b><br>Produtos</div><div class="card"><b>${DATA.clients.length}</b><br>Clientes</div><div class="card"><b>${DATA.routes.length}</b><br>Rotas</div><div class="card"><b>${DATA.orders.length}</b><br>Vendas/Pedidos</div></div>`}
function render(){renderHome();renderProducts();renderClients();renderRoutes();renderSales();renderOrders();renderSaleCart()}
load().catch(e=>alert('Não foi possível carregar o sistema: '+e.message));
</script>
</body></html>`;

async function init(db){
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS routes(id TEXT PRIMARY KEY,name TEXT NOT NULL,city TEXT NOT NULL,date TEXT,created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS clients(id TEXT PRIMARY KEY,name TEXT NOT NULL,phone TEXT,city TEXT NOT NULL,route_id TEXT NOT NULL,public_token TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,code TEXT,name TEXT NOT NULL,price REAL NOT NULL,photo_url TEXT,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,client_id TEXT,client_name TEXT NOT NULL,city TEXT,route_id TEXT,route_name TEXT,route_date TEXT,payment TEXT,total REAL NOT NULL,status TEXT NOT NULL,source TEXT NOT NULL,created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS order_items(id TEXT PRIMARY KEY,order_id TEXT NOT NULL,product_id TEXT,product_name TEXT NOT NULL,quantity INTEGER NOT NULL,unit_price REAL NOT NULL,line_total REAL NOT NULL)`)
  ]);
}
const uid=()=>crypto.randomUUID(), token=()=>crypto.randomUUID().replaceAll('-','');
const json=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{'content-type':'application/json;charset=UTF-8'}});

async function api(request,env){
  const db=env.DB;if(!db)return json({error:'Banco DB não está vinculado.'},500);
  await init(db);
  const u=new URL(request.url),p=u.pathname.replace(/^\/api\/?/,'');
  try{
    if(request.method==='GET'&&p==='bootstrap'){
      const [a,b,c,d]=await Promise.all([
        db.prepare('SELECT * FROM products WHERE active=1 ORDER BY name').all(),
        db.prepare('SELECT * FROM clients ORDER BY name').all(),
        db.prepare('SELECT * FROM routes ORDER BY date,name').all(),
        db.prepare(`SELECT o.*,COALESCE(json_group_array(CASE WHEN i.id IS NULL THEN NULL ELSE json_object('product_name',i.product_name,'quantity',i.quantity,'unit_price',i.unit_price,'line_total',i.line_total) END),'[]') items FROM orders o LEFT JOIN order_items i ON i.order_id=o.id GROUP BY o.id ORDER BY o.created_at DESC LIMIT 200`).all()
      ]);
      return json({products:a.results||[],clients:b.results||[],routes:c.results||[],orders:(d.results||[]).map(o=>({...o,items:JSON.parse(o.items||'[]').filter(Boolean)}))});
    }
    if(request.method==='GET'&&p==='catalog'){
      const t=u.searchParams.get('cliente');if(!t)return json({error:'Cliente não informado.'},400);
      const c=await db.prepare('SELECT id,name,city,route_id,public_token FROM clients WHERE public_token=?').bind(t).first();
      if(!c)return json({error:'Link de cliente inválido.'},404);
      const ps=await db.prepare('SELECT id,code,name,price,photo_url FROM products WHERE active=1 ORDER BY name').all();
      return json({client:c,products:ps.results||[]});
    }
    if(request.method==='POST'&&p==='routes'){
      const b=await request.json();if(!b.name||!b.city)return json({error:'Nome e cidade são obrigatórios.'},400);
      await db.prepare('INSERT INTO routes VALUES(?,?,?,?,?)').bind(uid(),b.name.trim(),b.city.trim(),b.date||'',new Date().toISOString()).run();return json({ok:true});
    }
    if(request.method==='POST'&&p==='clients'){
      const b=await request.json();if(!b.name||!b.route_id)return json({error:'Nome e rota são obrigatórios.'},400);
      const r=await db.prepare('SELECT * FROM routes WHERE id=?').bind(b.route_id).first();if(!r)return json({error:'Rota não encontrada.'},404);
      await db.prepare('INSERT INTO clients VALUES(?,?,?,?,?,?,?)').bind(uid(),b.name.trim(),b.phone||'',r.city,r.id,token(),new Date().toISOString()).run();return json({ok:true});
    }
    if(request.method==='POST'&&p==='products'){
      const b=await request.json();if(!b.name||!(Number(b.price)>0))return json({error:'Nome e preço são obrigatórios.'},400);
      await db.prepare('INSERT INTO products VALUES(?,?,?,?,?,?,?)').bind(uid(),b.code||'',b.name.trim(),Number(b.price),b.photo_url||'',1,new Date().toISOString()).run();return json({ok:true});
    }
    if(request.method==='POST'&&(p==='sales'||p==='orders')){
      const b=await request.json();let c=b.client_id?await db.prepare('SELECT * FROM clients WHERE id=?').bind(b.client_id).first():null;
      if(!c&&b.token)c=await db.prepare('SELECT * FROM clients WHERE public_token=?').bind(b.token).first();if(!c)return json({error:'Cliente não encontrado.'},404);
      const r=await db.prepare('SELECT * FROM routes WHERE id=?').bind(c.route_id).first();if(!r)return json({error:'Rota não encontrada.'},404);
      if(!Array.isArray(b.items)||!b.items.length)return json({error:'Nenhum produto informado.'},400);
      const items=[];for(const x of b.items){const pr=await db.prepare('SELECT * FROM products WHERE id=? AND active=1').bind(x.product_id).first();const q=Math.max(1,parseInt(x.quantity||1));if(!pr)return json({error:'Produto não encontrado.'},404);items.push({id:uid(),product_id:pr.id,product_name:pr.name,quantity:q,unit_price:pr.price,line_total:pr.price*q})}
      const total=items.reduce((s,x)=>s+x.line_total,0),oid=uid(),now=new Date().toISOString();
      await db.prepare('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(oid,c.id,c.name,c.city,r.id,r.name,r.date||'',b.payment||'60 dias',total,'Novo',p==='sales'?'vendedor':'cliente',now).run();
      await db.batch(items.map(x=>db.prepare('INSERT INTO order_items VALUES(?,?,?,?,?,?,?)').bind(x.id,oid,x.product_id,x.product_name,x.quantity,x.unit_price,x.line_total)));
      return json({ok:true,id:oid,total});
    }
    if(request.method==='PATCH'&&p.startsWith('orders/')){const oid=p.split('/')[1],b=await request.json();await db.prepare('UPDATE orders SET status=? WHERE id=?').bind(b.status||'Atendido',oid).run();return json({ok:true})}
    return json({error:'Rota não encontrada.'},404);
  }catch(e){return json({error:e.message||'Erro interno.'},500)}
}

export default {
  async fetch(request,env){
    const u=new URL(request.url);
    if(u.pathname.startsWith('/api/')) return api(request,env);
    if(u.pathname==='/catalog.html') return new Response(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#111"><title>Catálogo</title><style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;background:#f4f5f7;margin:0;padding:14px;color:#111}.wrap{max-width:700px;margin:auto}.top,.card{background:#fff;border:1px solid #ddd;border-radius:15px;padding:16px;margin-bottom:12px}.top{background:#111;color:#fff}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.prod{background:#fff;border:1px solid #ddd;border-radius:14px;overflow:hidden}.photo{height:160px;background:#eee;display:flex;align-items:center;justify-content:center;font-size:42px}.photo img{width:100%;height:100%;object-fit:cover}.info{padding:12px}.price{font-size:18px;font-weight:800;margin:6px 0}.btn{width:100%;background:#111;color:#fff;border:0;border-radius:10px;padding:13px;font-weight:700;font-size:15px}.row{display:flex;justify-content:space-between;gap:8px;align-items:center;margin:8px 0}.qty{width:70px;padding:10px;border:1px solid #ccc;border-radius:9px;font-size:16px}.total{display:flex;justify-content:space-between;font-size:19px;font-weight:800}@media(max-width:520px){.grid{grid-template-columns:1fr}}</style></head><body><div class="wrap"><div class="top"><h2>Catálogo de pedidos</h2><div id="who">Carregando...</div></div><div class="card"><div id="products" class="grid"></div></div><div class="card"><h3>Seu pedido</h3><div id="cart"></div><div class="total"><span>Total</span><span id="total">R$ 0,00</span></div><br><select id="pay" style="width:100%;padding:13px;border:1px solid #ccc;border-radius:10px;font-size:16px"><option>60 dias</option><option>À vista</option><option>Pix</option><option>Cartão</option></select><br><br><button class="btn" onclick="send()">Enviar pedido</button><div id="msg"></div></div></div><script>
const br=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(n);const q=new URLSearchParams(location.search).get('cliente');let D,cart={};const $=x=>document.getElementById(x);
async function load(){let r=await fetch('/api/catalog?cliente='+encodeURIComponent(q));D=await r.json();if(!r.ok){$('who').textContent=D.error;return}$('who').textContent='Cliente: '+D.client.name+' • '+D.client.city;$('products').innerHTML=D.products.map(p=>'<div class="prod"><div class="photo">'+(p.photo_url?'<img src="'+p.photo_url+'">':'📦')+'</div><div class="info"><b>'+p.name+'</b><div class="price">'+br(p.price)+'</div><div class="row"><input class="qty" id="q_'+p.id+'" type="number" min="0" value="0"><button class="btn" style="width:auto" onclick="add(\''+p.id+'\')">Adicionar</button></div></div></div>').join('')}
function add(id){let n=parseInt($('q_'+id).value||0);if(n<1)return;cart[id]=(cart[id]||0)+n;$('q_'+id).value=0;draw()}
function draw(){let total=0,html='';for(let id in cart){let p=D.products.find(x=>x.id===id),t=p.price*cart[id];total+=t;html+='<div class="row"><span>'+cart[id]+'x '+p.name+'</span><b>'+br(t)+'</b></div>'} $('cart').innerHTML=html||'<div style="color:#777">Nenhum produto.</div>';$('total').textContent=br(total)}
async function send(){let items=Object.entries(cart).map(([product_id,quantity])=>({product_id,quantity}));if(!items.length)return alert('Adicione produtos.');let r=await fetch('/api/orders',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({token:q,payment:$('pay').value,items})});let x=await r.json();if(!r.ok)return alert(x.error);$('msg').innerHTML='<div style="background:#e9f8ed;padding:12px;border-radius:10px;margin-top:10px">Pedido enviado com sucesso! Total: '+br(x.total)+'</div>';cart={};draw()}load()
</script></body></html>`);
    return new Response(html,{headers:{'content-type':'text/html;charset=UTF-8'}});
  }
};